#!/bin/sh -e

if [ $# -lt 2 ]; then
    echo "Usage: $0 <dir> <board-name>"
    exit 1
fi

DIR="$1"
BOARD_NAME=$2

mv "$DIR"/$BOARD_NAME.drl "$DIR"/$BOARD_NAME.TXT
mv "$DIR"/$BOARD_NAME-B.Cu.gbl "$DIR"/$BOARD_NAME.GBL
mv "$DIR"/$BOARD_NAME-B.Mask.gbs "$DIR"/$BOARD_NAME.GBS
mv "$DIR"/$BOARD_NAME-B.SilkS.gbo "$DIR"/$BOARD_NAME.GBO
mv "$DIR"/$BOARD_NAME-Edge.Cuts.gm1 "$DIR"/$BOARD_NAME.GML
mv "$DIR"/$BOARD_NAME-F.Cu.gtl "$DIR"/$BOARD_NAME.GTL
mv "$DIR"/$BOARD_NAME-F.Mask.gts "$DIR"/$BOARD_NAME.GTS
mv "$DIR"/$BOARD_NAME-F.SilkS.gto "$DIR"/$BOARD_NAME.GTO

